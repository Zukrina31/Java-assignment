/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package GUI;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

/**
 *
 * @author yibei
 */
public class customerid {
    private int id;

    public customerid(int id) {
        this.id = 1;
    }

    public int getId() {
        return id;
    }
    
    FileReader file;
    
    public customerid() throws FileNotFoundException, IOException {
        this.file = new FileReader("customerinfo.txt");
        BufferedReader reader = new BufferedReader(file);
        String line;
        while((line = reader.readLine()) != null) {
            String[] info = line.split(",");
            while(Integer.parseInt(info[0]) == id) {
                this.id = Integer.parseInt(info[0]) + 1;
            }
        }
    }
    
    
    
}
